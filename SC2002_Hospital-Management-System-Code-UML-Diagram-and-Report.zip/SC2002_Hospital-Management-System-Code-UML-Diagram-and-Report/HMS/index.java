package HMS;

public class index {

	public static void main(String[] Args)
	{	
		Login log = new Login();
	}
}
