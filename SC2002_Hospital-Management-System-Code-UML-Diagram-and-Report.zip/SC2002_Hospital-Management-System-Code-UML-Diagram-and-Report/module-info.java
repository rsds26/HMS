/**
 * 
 */
/**
 * 
 */
module OOP_Project {
	requires org.apache.poi.ooxml;
	requires org.apache.poi.poi;
}